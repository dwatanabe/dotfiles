RSense
======

Documentation
-------------
This is a mirror of http://cx4a.org/software/rsense/ modified to work with pathogen and vim-update-bundles

* http://cx4a.org/software/rsense/
* doc/index.txt

License
-------

RSense is distributed under the term of GPLv3+. And its documentations under doc directory is distributed under the term of GFDL.
