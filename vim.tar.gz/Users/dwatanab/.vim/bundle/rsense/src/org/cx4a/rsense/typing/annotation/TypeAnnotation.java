package org.cx4a.rsense.typing.annotation;

public interface TypeAnnotation {
}
