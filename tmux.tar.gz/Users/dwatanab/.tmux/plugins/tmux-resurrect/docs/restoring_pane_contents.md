# Restoring pane contents

This plugin enables saving and restoring tmux pane contents.

This feature can be enabled by adding this line to `.tmux.conf`:

    set -g @resurrect-capture-pane-contents 'on'
